#!/bin/sh

touch /tmp/test
echo "test hook works"
rm /tmp/test

